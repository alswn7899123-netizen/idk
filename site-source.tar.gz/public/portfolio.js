// Native anchors and details remain usable without JavaScript.
// Reveal a legacy deep link after its case has moved to a dedicated category.
const redirects = {
  'partnership.html#mediheal': 'relationship.html#mediheal',
  'partnership.html#manyo': 'relationship.html#manyo',
  'matching.html#knotted': 'planning.html#knotted',
  'operations.html#canesten': 'planning.html#canesten',
  'commerce.html#lotteria': 'matching.html#lotteria',
  'channels.html#owned-channel': 'channels.html#guesthouse',
  'career.html#different': 'career.html#organization'
};
const pageName = location.pathname.split('/').pop() || 'index.html';
const target = redirects[pageName + location.hash];
if (target) location.replace(target);

const tabs = [...document.querySelectorAll('.document-tabs [role="tab"]')];
if (tabs.length) {
  const panels = tabs.map(tab => document.getElementById(tab.getAttribute('aria-controls')));
  function selectTab(index, updateHash = false) {
    tabs.forEach((tab, i) => {
      const selected = i === index;
      tab.setAttribute('aria-selected', String(selected));
      tab.tabIndex = selected ? 0 : -1;
      panels[i].hidden = !selected;
      panels[i].classList.remove('is-entering');
    });
    void panels[index].offsetWidth;
    panels[index].classList.add('is-entering');
    if (updateHash) history.replaceState(null, '', index ? '#portfolio' : '#resume');
  }
  function followHash() {
    const hash = location.hash.slice(1);
    const anchor = document.getElementById(hash);
    const index = hash === 'portfolio' || (anchor && panels[1].contains(anchor)) ? 1 : 0;
    selectTab(index);
    if (hash === 'portfolio') {
      requestAnimationFrame(() => document.querySelector('.document-tabs').scrollIntoView({behavior: 'instant', block: 'start'}));
    } else if (anchor && !['panel-resume', 'panel-portfolio'].includes(hash)) {
      requestAnimationFrame(() => anchor.scrollIntoView({behavior: 'instant', block: 'start'}));
    }
  }
  tabs.forEach((tab, i) => {
    tab.addEventListener('click', () => selectTab(i, true));
    tab.addEventListener('keydown', event => {
      if (!['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
      event.preventDefault();
      const next = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : (i + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
      selectTab(next, true);
      tabs[next].focus();
    });
  });
  window.addEventListener('hashchange', followHash);
  if (location.hash) followHash();
  else selectTab(1);
}
window.setTimeout(() => document.documentElement.classList.remove('intro-motion'), 1100);

// Month-based experience in Seoul; Proven internship is excluded.
function careerMonthIndex(value) {
  const [year, month] = value.split('-').map(Number);
  return year * 12 + month - 1;
}
function getCareerSummary(now = new Date()) {
  const parts = new Intl.DateTimeFormat('en-US', { timeZone: 'Asia/Seoul', year: 'numeric', month: 'numeric' }).formatToParts(now);
  const year = Number(parts.find(part => part.type === 'year').value);
  const month = Number(parts.find(part => part.type === 'month').value);
  const current = year * 12 + month - 1;
  const periods = [
    { start: '2024-10', end: null },
    { start: '2022-02', end: '2023-10' },
    { start: '2021-04', end: '2021-07' }
  ];
  const months = periods.reduce((total, period) => total + Math.max(0, (period.end ? careerMonthIndex(period.end) : current) - careerMonthIndex(period.start)), 0);
  return { text: `${Math.floor(months / 12)}년 ${months % 12}개월`, title: `${year}년 ${month}월 기준 · 프로븐 인턴 제외` };
}
function updateCareerSummary() {
  const summary = getCareerSummary();
  document.querySelectorAll('[data-career-total]').forEach(element => {
    if (element.textContent !== summary.text) element.textContent = summary.text;
    element.title = summary.title;
  });
}
updateCareerSummary();
// Also handle a page kept open across a month boundary, or resumed from sleep.
window.setInterval(updateCareerSummary, 60000);
window.addEventListener('pageshow', updateCareerSummary);
document.addEventListener('visibilitychange', () => { if (!document.hidden) updateCareerSummary(); });

// Keep campaign navigation visible and track the section being read.
const campaignNavigation = [...document.querySelectorAll('[data-tab-group]')].map(nav => ({
  nav,
  links: [...nav.querySelectorAll('a[href^="#"]')]
})).map(group => ({...group, sections: group.links.map(link => document.getElementById(link.hash.slice(1)))}));
let compactCampaignNav = null;
const campaignBranchNav = document.querySelector('.branch-tabs');
function measureCampaignNavigation() {
  const headerHeight = document.querySelector('.site-header')?.getBoundingClientRect().height || 0;
  const branchHeight = campaignBranchNav?.getBoundingClientRect().height || 0;
  const leafHeight = Math.max(0, ...campaignNavigation.filter(group => group.nav.classList.contains('leaf-tabs')).map(group => group.nav.getBoundingClientRect().height));
  document.documentElement.style.setProperty('--site-header-height', `${headerHeight}px`);
  document.documentElement.style.setProperty('--campaign-branch-height', `${branchHeight}px`);
  document.documentElement.style.setProperty('--campaign-leaf-height', `${leafHeight}px`);
}
function updateCampaignNavigation() {
  const header = document.querySelector('.site-header')?.getBoundingClientRect().height || 0;
  const branch = document.body.classList.contains("campaign-compact") ? 48 : (campaignBranchNav?.getBoundingClientRect().height || 0);
  for (const group of campaignNavigation) {
    const line = header + branch + (!document.body.classList.contains('campaign-compact') && group.nav.classList.contains('leaf-tabs') ? group.nav.getBoundingClientRect().height : 0) + 24;
    let active = 0;
    group.sections.forEach((section, index) => { if (section && section.getBoundingClientRect().top <= line) active = index; });
    group.links.forEach((link, index) => {
      if (index === active) link.setAttribute('aria-current', 'location');
      else link.removeAttribute('aria-current');
    });
  }
}
let campaignScrollFrame = 0;
function scheduleCampaignNavigation() {
  if (campaignScrollFrame) return;
  campaignScrollFrame = requestAnimationFrame(() => { campaignScrollFrame = 0; compactCampaignNav?.update(); updateCampaignNavigation(); compactCampaignNav?.label(); });
}
for (const group of campaignNavigation) {
  group.links.forEach((link, index) => link.addEventListener('click', event => {
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return;
    const section = group.sections[index];
    if (!section) return;
    event.preventDefault();
    history.pushState(null, '', link.hash);
    measureCampaignNavigation();
    const header = document.querySelector('.site-header')?.getBoundingClientRect().height || 0;
    const branch = document.body.classList.contains("campaign-compact") ? 48 : (campaignBranchNav?.getBoundingClientRect().height || 0);
    const leaf = document.body.classList.contains('campaign-compact') ? 0 : (group.nav.classList.contains('leaf-tabs') ? group.nav.getBoundingClientRect().height : 0);
    window.scrollTo({top: section.getBoundingClientRect().top + window.scrollY - header - branch - leaf - 16, behavior: 'instant'});
    if (!matchMedia('(prefers-reduced-motion: reduce)').matches && section.animate) section.animate([{opacity: 0.65}, {opacity: 1}], {duration: 180, easing: 'ease-out'});
    group.links.forEach((item, i) => { if (i === index) item.setAttribute('aria-current', 'location'); else item.removeAttribute('aria-current'); });
  }));
}
window.addEventListener('scroll', scheduleCampaignNavigation, {passive:true});
window.addEventListener('resize', () => { measureCampaignNavigation(); scheduleCampaignNavigation(); });
window.addEventListener('hashchange', scheduleCampaignNavigation);
if (typeof ResizeObserver !== 'undefined') {
  const campaignNavResize = new ResizeObserver(() => { measureCampaignNavigation(); scheduleCampaignNavigation(); });
  [document.querySelector('.site-header'), ...campaignNavigation.map(group => group.nav)].filter(Boolean).forEach(node => campaignNavResize.observe(node));
}
measureCampaignNavigation();
updateCampaignNavigation();

// Compact reading navigation, without changing document flow or hiding campaigns.
if (campaignBranchNav) {
  const sentinel = document.createElement('span');
  sentinel.setAttribute('aria-hidden', 'true');
  campaignBranchNav.before(sentinel);
  const bar = document.createElement('div');
  bar.className = 'campaign-reading-nav';
  bar.hidden = true;
  const toggle = document.createElement('button');
  toggle.type = 'button';
  toggle.className = 'campaign-reading-toggle';
  toggle.setAttribute('aria-expanded', 'false');
  toggle.setAttribute('aria-controls', 'campaign-reading-menu');
  const menu = document.createElement('nav');
  menu.id = 'campaign-reading-menu';
  menu.className = 'campaign-reading-menu';
  menu.setAttribute('aria-label', '캠페인 분류 선택');
  menu.hidden = true;
  const cloneLinks = [];
  campaignNavigation.forEach(group => {
    const row = document.createElement('div');
    row.className = 'campaign-reading-options';
    group.links.forEach(link => {
      const clone = link.cloneNode(true);
      clone.removeAttribute('id');
      clone.addEventListener('click', event => {
        if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
        event.preventDefault();
        close();
        link.click();
        scheduleCampaignNavigation();
        toggle.focus({preventScroll:true});
      });
      cloneLinks.push([clone,link]);
      row.append(clone);
    });
    menu.append(row);
  });
  bar.append(toggle,menu);
  document.body.append(bar);
  function close() { menu.hidden = true; toggle.setAttribute('aria-expanded','false'); }
  toggle.addEventListener('click', () => {
    menu.hidden = !menu.hidden;
    toggle.setAttribute('aria-expanded',String(!menu.hidden));
  });
  document.addEventListener('click', event => { if (!bar.contains(event.target)) close(); });
  bar.addEventListener('keydown', event => { if(event.key === 'Escape') { close(); toggle.focus(); } });
  const clean = link => link?.textContent.replace(/^\s*\d+\)?\s*/, '').trim() || '';
  compactCampaignNav = {
    update() {
      const panel = campaignBranchNav.closest('.full-category');
      const header = document.querySelector('.site-header')?.getBoundingClientRect().height || 0;
      const bounds = panel?.getBoundingClientRect();
      const visible = campaignBranchNav.getClientRects().length && sentinel.getBoundingClientRect().top < header - 160 && bounds?.bottom > header + 80;
      document.body.classList.toggle('campaign-compact', Boolean(visible));
      bar.hidden = !visible;
      if (!visible) close();
      const rect = campaignBranchNav.getBoundingClientRect();
      bar.style.left = rect.left + 'px';
      bar.style.width = rect.width + 'px';
      bar.style.top = header + 'px';
    },
    label() {
      const branchLink = campaignBranchNav.querySelector('[aria-current="location"]');
      const branch = branchLink && document.getElementById(branchLink.hash.slice(1));
      const leaf = branch?.querySelector('.leaf-tabs [aria-current="location"]');
      const label = [clean(branchLink),clean(leaf)].filter(Boolean).join(' › ');
      toggle.textContent = label + '  ▾';
      toggle.setAttribute('aria-label', label + ' · 분류 선택');
      cloneLinks.forEach(([clone,original]) => {
        if(original.hasAttribute('aria-current') && (original.closest('.branch-tabs') || branch?.contains(original))) clone.setAttribute('aria-current','location');
        else clone.removeAttribute('aria-current');
      });
    }
  };
  new MutationObserver(scheduleCampaignNavigation).observe(document.querySelector('#panel-portfolio') || campaignBranchNav.parentElement, {attributes:true,attributeFilter:['hidden']});
  scheduleCampaignNavigation();
}
