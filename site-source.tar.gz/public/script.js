const nav = document.getElementById('nav');
const updateNav = () => nav.classList.toggle('scrolled', window.scrollY > 40);
window.addEventListener('scroll', updateNav, {passive:true});
updateNav();
// Count each result once as it enters the viewport; retain its exact unit and final value.
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
if (!reducedMotion && 'IntersectionObserver' in window) {
  const counts = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      counts.unobserve(el);
      const final = el.textContent.trim();
      const match = final.match(/^(\+?)([\d,]+(?:\.\d+)?)([^\d]*)$/);
      if (!match) return;
      const value = Number(match[2].replaceAll(',', ''));
      const decimals = (match[2].split('.')[1] || '').length;
      const grouping = match[2].includes(',');
      el.setAttribute('aria-label', final);
      const span = document.createElement('span');
      span.setAttribute('aria-hidden', 'true');
      el.replaceChildren(span);
      const started = performance.now();
      function frame(now) {
        const progress = Math.min((now - started) / 1150, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        const current = value * eased;
        span.textContent = progress === 1 ? final : match[1] + current.toLocaleString('en-US', {minimumFractionDigits:decimals, maximumFractionDigits:decimals, useGrouping:grouping}) + match[3];
        if (progress < 1) requestAnimationFrame(frame);
      }
      requestAnimationFrame(frame);
    });
  }, {threshold:.45});
  document.querySelectorAll('.metric-num,.case-metric strong,.minju-kpi-card strong,.impact-num,.category-proof strong').forEach(el => counts.observe(el));
}
// Keep the original reference's fade-up behavior, with readable no-script content.
if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches && 'IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {entry.target.classList.add('fade-up');observer.unobserve(entry.target);}
    });
  }, {threshold:.06});
  document.querySelectorAll('.channel-card,.org-card,.different-card,.timeline-item,.impact-card').forEach(el => observer.observe(el));
}
